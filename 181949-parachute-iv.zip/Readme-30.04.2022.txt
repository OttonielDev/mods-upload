[RU]
Parachute IV

Для Вас, мои дорогие друзья, сегодня представляем новую модификацию Parachute IV для GTA 4.

Особенности:
- Добавляет возможность контролировать свободное падение и использовать парашют почти как в TBoGT;
- Приятной особенностью этого мода является возможность использовать оружие, находясь на парашюте;
- При входе в вертолет вы автоматически получите парашют, как в GTA V.

На карте вы найдете несколько меток с текстом «Pb», куда вы можете отправиться, чтобы совершить прыжок с парашютом.

Горячие клавиши:
E - Перейти к месту прыжка/Отпустить парашют и упасть
Left mouse button - Открыть парашют
Insert - Показать меню модов.

Чтобы бесплатно скачать мод Parachute IV для GTA 4, нужно просто кликнуть по ссылкам внизу страницы. Автоматизированный инсталлятор поможет Вам в два нажатия установить мод.
Приятной игры!

https://www.gtavicecity.ru/gta-4/mods/181949-parachute-iv.html

################################################################################################

[EN]
Parachute IV

For you, my dear friends, today we present a new modification of The Parachute IV for GTA 4.

Features:
- Adds the ability to control free fall and use the parachute almost like in TBoGT;
- A nice feature of this mod is the ability to use weapons while on a parachute;
- When entering the helicopter you will automatically receive a parachute, as in GTA V.

On the map you will find several labels with the text "Pb", where you can go to make a parachute jump.

Keyboard shortcuts:
E - Jump to the jump site/Release the parachute and fall
Left mouse button - Open parachute
Insert - Show mod menu.

To free download mod Parachute IV for GTA 4, you just need to click on the links at the bottom of the page. An automated installer will help you install the mod in two clicks.
Enjoy the game!

https://www.gtaall.com/gta-4/mods/181949-parachute-iv.html

################################################################################################

[FR]
Parachute IV

Pour vous, mes chers amis, nous vous présentons aujourd’hui une nouvelle modification de The Parachute IV pour GTA 4.

Fonctionnalités:
- Ajoute la possibilité de contrôler la chute libre et d’utiliser le parachute presque comme dans TBoGT;
- Une caractéristique intéressante de ce mod est la possibilité d’utiliser des armes en parachute;
- En entrant dans l’hélicoptère, vous recevrez automatiquement un parachute, comme dans GTA V.

Sur la carte, vous trouverez plusieurs étiquettes avec le texte « Pb », où vous pouvez aller faire un saut en parachute.

Raccourcis clavier :
E - Sauter sur le site de saut/Relâcher le parachute et tomber
Bouton gauche de la souris - Ouvrir le parachute
Insérer - Afficher le menu mod.

Pour télécharger gratuitement le mod Parachute IV pour GTA 4, il vous suffit de cliquer sur les liens en bas de la page. Un programme d’installation automatisé vous aidera à installer le mod en deux clics.
Profitez du jeu!

https://www.gtaall.eu/fr/gta-4/mods/181949-parachute-iv.html

################################################################################################

[DE]
Parachute IV

Für euch, meine lieben Freunde, präsentieren wir heute eine neue Modifikation von The Parachute IV für GTA 4.

Funktionen:
- Fügt die Fähigkeit hinzu, den freien Fall zu kontrollieren und den Fallschirm fast wie in TBoGT zu benutzen;
- Ein nettes Feature dieses Mods ist die Fähigkeit, Waffen zu benutzen, während man sich auf einem Fallschirm befindet;
- Beim Betreten des Hubschraubers erhalten Sie automatisch einen Fallschirm, wie in GTA V.

Auf der Karte finden Sie mehrere Beschriftungen mit dem Text "Pb", wo Sie einen Fallschirmsprung machen können.

Tastenkombinationen:
E - Sprung zur Sprungstelle/Fallschirm loslassen und fallen
Linke Maustaste - Fallschirm öffnen
Einfügen - Mod-Menü anzeigen.

Um Mod Parachute IV für GTA 4 kostenlos herunterzuladen, müssen Sie nur auf die Links unten auf der Seite klicken. Ein automatisiertes Installationsprogramm hilft Ihnen, den Mod mit zwei Klicks zu installieren.
Viel Spaß mit dem Spiel!

https://www.gtaall.eu/de/gta-4/mods/181949-parachute-iv.html

################################################################################################

[ES]
Parachute IV

Para vosotros, mis queridos amigos, hoy os presentamos una nueva modificación de El Paracaídas IV para GTA 4.

Funciones:
- Añade la capacidad de controlar la caída libre y utilizar el paracaídas casi como en TBoGT;
- Una buena característica de este mod es la capacidad de usar armas mientras está en un paracaídas;
- Al entrar en el helicóptero recibirás automáticamente un paracaídas, como en GTA V.

En el mapa encontrarás varias etiquetas con el texto "Pb", donde puedes ir a hacer un salto en paracaídas.

Métodos abreviados de teclado:
E - Saltar al sitio de salto / Soltar el paracaídas y caer
Botón izquierdo del ratón - Abrir paracaídas
Insertar - Mostrar menú mod.

Para descargar gratis mod Parachute IV para GTA 4, solo necesita hacer clic en los enlaces en la parte inferior de la página. Un instalador automatizado le ayudará a instalar el mod en dos clics.
¡Disfruta del juego!

https://www.gtaall.net/gta-4/mods/181949-parachute-iv.html

################################################################################################

[PT]
Parachute IV

Para vocês, meus queridos amigos, hoje apresentamos uma nova modificação do Paraquedas IV para GTA 4.

Características:
- Adiciona a capacidade de controlar a queda livre e usar o paraquedas quase como no TBoGT;
- Uma boa característica deste mod é a capacidade de usar armas enquanto em um paraquedas;
- Ao entrar no helicóptero você receberá automaticamente um paraquedas, como em GTA V.

No mapa você encontrará vários rótulos com o texto "Pb", onde você pode ir para fazer um salto de paraquedas.

Atalhos de teclado:
E - Pule para o local do salto/Solte o paraquedas e caia
Botão do mouse esquerdo - Paraquedas aberto
Inserir - Mostrar menu mod.

Para baixar gratuitamente mod Parachute IV para GTA 4, basta clicar nos links na parte inferior da página. Um instalador automatizado irá ajudá-lo a instalar o mod em dois cliques.
Aproveite o jogo!

https://www.gtaall.com.br/gta-4/mods/181949-parachute-iv.html